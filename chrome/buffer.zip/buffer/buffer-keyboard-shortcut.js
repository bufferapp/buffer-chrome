$(document).ready(function(){
	$(document).bind('keydown', 'alt+b', function(){
		BufferBookmarklet();
	});
});