// Called when the user clicks on the browser action.
  chrome.browserAction.onClicked.addListener(function(tab) {
    chrome.tabs.executeScript(null, {file: "buffer.js"});
  });

	//   chrome.browserAction.setBadgeBackgroundColor({color:[0, 200, 0, 100]});
	// 
	//   window.setInterval(function() {
	// $.getJSON("http://bufferapp.com/api/num_in_buffer/", function(result){
	//   	if(result.success) {
	// 		if(parseInt(result.tweets) == 0) chrome.browserAction.setBadgeBackgroundColor({color:[208, 0, 16, 0]});
	// 		else chrome.browserAction.setBadgeBackgroundColor({color:[0, 200, 0, 100]});
	// 		chrome.browserAction.setBadgeText({text:String(result.tweets)});
	// 	} else {
	// 		chrome.browserAction.setBadgeText({text:String('')});
	// 		chrome.browserAction.setBadgeBackgroundColor({color:[0, 208, 0, 16]});
	// 	}
	// });
	//   }, 5000);

	