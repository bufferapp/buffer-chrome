var c=document.getElementsByTagName('body')[0],d=document.createElement('input');d.type='hidden';d.name='bufferapp_source';d.value='chrome';c.appendChild(d);
var a=document.getElementsByTagName('head')[0],b=document.createElement('script');b.type='text/javascript';b.src='http://bufferapp.com/js/bookmarklet.v1.js?'+Math.floor(Math.random()*99999);a.appendChild(b);
