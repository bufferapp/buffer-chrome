;(function() {

  document.body.classList.add('BUFFER');

}());
