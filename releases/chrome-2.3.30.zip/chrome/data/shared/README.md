buffer-extension-shared
=======================

Shared code between Buffer extensions
